import random
import numpy as np
import math
import torch


class Hexagon():
    def __init__(self, size):
        self.size = size
        self.xs = [x for x in range(3 * size ** 2 + 3 * size + 1)]
        self.actions = [
            np.array([1, 0]), np.array([1 / 2, math.sqrt(3) / 2]),
            np.array([-1 / 2, math.sqrt(3) / 2]), np.array([-1, 0]),
            np.array([-1 / 2, -math.sqrt(3) / 2]), np.array([1 / 2, -math.sqrt(3) / 2])
        ]  # todo： no static actions
        random.shuffle(self.xs)
        # --------generate gs------------------
        self.gs = [np.array([0, 0])]
        for s in range(self.size):
            g_new = [(s + 1) * a for a in self.actions]
            self.gs.extend(g_new)
            for gi in range(len(g_new)):
                a = g_new[gi]
                b = g_new[gi + 1] if (gi + 1 < len(g_new)) else g_new[0]
                for n in range(s + 1):
                    if n >= 1:
                        self.gs.append((a * n + b * (s + 1 - n)) / (s + 1))
        # -------generate interface------------
        self.interface = random.randint(len(self.gs) - self.size * 6, len(self.gs) - 1)
        # self.gs[-size*6, -1] is the outer circle
        while True:
            a = random.randint(0, 5)
            in_gs_flag = False
            for j, v in enumerate(self.gs):
                if np.abs(self.gs[self.interface] + self.actions[a] - v).sum().round().item() == 0:
                    in_gs_flag = True
                    break
            if not in_gs_flag:
                self.interface_action = a
                break
        # -----------------------------------------

    def walk(self, seq_len, start_point=False, exit_point=False, visit_history=None):
        # start point: if False, start randomly; if True ,start from interface
        # exit_point: if False, don't exit until seq_len; if True, exit when taking interface_action in the interface
        # visit_history: the history in the env, used to generate visited_list
        # return x->a->x->a...
        # a [seq_len,], x [seq_len,], visited[seq_len]

        x_list = []
        a_list = []
        visited_list = []
        if visit_history is None:
            visit_history = []
        if start_point:
            i = self.interface
        else:
            i = random.randint(0, len(self.gs) - 1)
        for _ in range(seq_len):
            x = self.xs[i]
            g = self.gs[i]
            visited_list.append(i in visit_history)
            visit_history.append(i)
            while True:
                a = random.randint(0, 5)
                if exit_point and i == self.interface and a == self.interface_action:
                    x_list.append(x)
                    a_list.append(a)
                    if not start_point:
                        # todo: if start_point==False, the agent comes from blandly new
                        # pay attention that there are multi-definition of switch_list here
                        switch_list = [0 for _ in range(len(x_list))]
                    else:
                        switch_list = [(i+1) for i in range(len(x_list))]
                    return x_list, a_list, visited_list, switch_list, visit_history

                in_gs_flag = False
                for j, v in enumerate(self.gs):
                    if np.abs(g + self.actions[a] - v).sum().round().item() == 0:
                        g = v.copy()
                        i = j
                        in_gs_flag = True
                        break
                if in_gs_flag:
                    break
            x_list.append(x)
            a_list.append(a)

        if not start_point:
            # todo: if start_point==False, the agent comes from blandly new
            # pay attention that there are multi-definition of switch_list here
            switch_list = [0 for _ in range(len(x_list))]
        else:
            switch_list = [(i + 1) for i in range(len(x_list))]

        return x_list, a_list, visited_list, switch_list, visit_history


class Square():
    def __init__(self, size):
        # size: number of nodes in each side
        self.size = size
        self.xs = [x for x in range(size ** 2)]  # todo: x no repeat now
        self.actions = [[0, 0], [0, 1], [1, 0], [-1, 0], [0, -1]]
        random.shuffle(self.xs)
        # --------------set interface-------------------
        self.interface = [0, self.size // 2]
        self.interface_action = 3  # self.actions[3] = [-1, 0]
        interface_set = [
            [[0, self.size // 2], 3], [[self.size - 1, self.size // 2], 2],
            [[self.size // 2, 0], 4], [[self.size // 2, self.size - 1], 1],
        ]
        # interface_actions are [-1,0], [1,0], [0,-1], [0,1]
        self.interface, self.interface_action = interface_set[random.randint(0, 3)]

    def walk(self, seq_len, start_point=False, exit_point=False, visit_history=None):
        # return x->a->x->a...
        # a [seq_len,], x [seq_len,], visited[seq_len]

        x_list = []
        a_list = []
        visited_list = []
        if visit_history is None:
            visit_history = []
        if start_point:
            i = self.interface[0]
            j = self.interface[1]
        else:
            i = random.randint(0, self.size - 1)
            j = random.randint(0, self.size - 1)
        for _ in range(seq_len):
            x = self.xs[i * self.size + j]
            visited_list.append([i, j] in visit_history)
            visit_history.append([i, j])
            while True:
                a = random.randint(0, 4)
                if exit_point \
                        and i == self.interface[0] \
                        and j == self.interface[1] \
                        and a == self.interface_action:
                    x_list.append(x)
                    a_list.append(a)
                    if not start_point:
                        # todo: if start_point==False, the agent comes from blandly new
                        # the setting of switch_list has been different from previous
                        # pay attention that there are multi-definition of switch_list here
                        switch_list = [0 for _ in range(len(x_list))]
                    else:
                        switch_list = [(i + 1) for i in range(len(x_list))]
                    return x_list, a_list, visited_list, switch_list, visit_history
                if i + self.actions[a][0] < self.size \
                        and i + self.actions[a][0] >= 0 \
                        and j + self.actions[a][1] < self.size \
                        and j + self.actions[a][1] >= 0:
                    i = i + self.actions[a][0]
                    j = j + self.actions[a][1]
                    break
            x_list.append(x)
            a_list.append(a)
        if not start_point:
            # todo: optional, if start_point==False, the agent comes from blandly new
            # pay attention that there are multi-definition of switch_list here
            switch_list = [0 for _ in range(len(x_list))]
        else:
            switch_list = [(i + 1) for i in range(len(x_list))]
        return x_list, a_list, visited_list, switch_list, visit_history


class HexagonSquare():
    def __init__(self, hexagon_size, square_size):
        self.hexagon = Hexagon(size=hexagon_size)
        self.square = Square(size=square_size)

    def walk(self, seq_len):
        # x->a->x->a->...
        # visited_history, switch_history are aligned to x
        # switch==1 means the first step from old env to a new one
        # switch==0 means the env has not switched yet

        x_list = []
        a_list = []
        visited_list = []
        switch_list = []
        visit_history_square = []
        visit_history_hexagon = []

        while len(x_list) < seq_len:
            # if x_list is [], start_point is False, start from random position --done

            if bool(x_list) or (random.random() < 0.5):
                # if x_list is [], with p=0.5, start from square, else start from hexagon
                x, a, visited, switch, visit_history_square = self.square.walk(seq_len, start_point=bool(x_list),
                                                                                   exit_point=True,
                                                                                   visit_history=visit_history_square)
                # todo: check x, a relation, check switch_list
                # todo: give visit_histoy when switch env?
                x_list.extend(x)
                a_list.extend(a)
                visited_list.extend(visited)
                switch_list.extend(switch)

            x, a, visited, switch, visit_history_hexagon = self.hexagon.walk(seq_len,
                                                                             start_point=bool(x_list), exit_point=True,
                                                                             visit_history=visit_history_hexagon)
            x = [xi + self.square.size ** 2 for xi in x]  # todo: optional
            for i in range(len(a)):
                if a[i] == 0 and random.random() < 0.5:
                    a[i] = 5
            # todo: correct action 0~4, 0~5
            # actions in square are in range(0, 4),
            # if we replace some 0 with 5,it will be in range(0, 5)
            x_list.extend(x)
            a_list.extend(a)
            visited_list.extend(visited)
            switch_list.extend(switch)
        return x_list[:seq_len], a_list[:seq_len], visited_list[:seq_len], switch_list[:seq_len], None


class PolygonDataset():
    def __init__(self, size, shape, params):
        self.size = size
        self.shape = shape
        self.buffer = {'xs':[], 'actions':[], 'visiteds':[], 'switchs':[]}

    def sample_from_new_mapping(self, seq_len, bs, append_to_buffer):
        if self.shape == 'Square':
            maps = [Square(self.size) for _ in range(bs)]
        elif self.shape == 'Hexagon':
            maps = [Hexagon(self.size) for _ in range(bs)]
            self.polygon = Hexagon
        else:
            assert self.shape == 'HexagonSquare'
            maps = [HexagonSquare(hexagon_size=self.size // 2, square_size=self.size) for _ in range(bs)]
            # todo: set size

        xs = []
        actions = []
        visiteds = []
        switchs = []
        for s in maps:
            x, a, visited, switch, _ = s.walk(seq_len)
            xs.append(x)
            actions.append(a)
            visiteds.append(visited)
            switchs.append(switch)
        if append_to_buffer:
            self.buffer['xs'].extend(xs)
            self.buffer['actions'].extend(actions)
            self.buffer['visiteds'].extend(visiteds)
            self.buffer['switchs'].extend(switchs)
        return xs, actions, visiteds, switchs

    def sample_from_buffer(self, bs):
        seq_index = [random.randint(0, len(self.buffer['xs']) - 1) for _ in range(bs)]
        xs = []
        actions = []
        visiteds = []
        switchs = []
        for b in range(bs):
            xs.append(self.buffer['xs'][seq_index[b]])
            actions.append(self.buffer['actions'][seq_index[b]])
            visiteds.append(self.buffer['visiteds'][seq_index[b]])
            switchs.append(self.buffer['switchs'][seq_index[b]])
        return xs, actions, visiteds, switchs

    def del_buffer_from_head(self, del_len):
        self.buffer['xs'] = self.buffer['xs'][del_len:]
        self.buffer['actions'] = self.buffer['actions'][del_len:]
        self.buffer['visiteds'] = self.buffer['visiteds'][del_len:]
        self.buffer['switchs'] = self.buffer['switchs'][del_len:]



if __name__ == '__main__':
    h = Hexagon(size=3)
    print(h.walk(seq_len=10))
    p = PolygonDataset(size=3, shape='HexagonSquare', params=None)
    p.sample_from_new_mapping(seq_len=500, bs=50, append_to_buffer=False)
