"""
train SAM model on square env, Jan 13, 2021
"""

from tqdm import tqdm
import numpy as np

import torch
from torch import nn, optim
import matplotlib.pyplot as plt

from baselines.sam.args import get_parser
from square_map import PolygonDataset
from baselines.sam.stm_basic import STM

args = get_parser().parse_args()

def plot_and_print(losses, accs, smooth_length):
    def namestr(obj):
        return [name for name in globals() if globals()[name] is obj][0]
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax2 = ax1.twinx()
    l = smooth_length # len(train_loader)
    for loss in losses:
        ax1.plot(np.convolve(np.array(loss), np.ones(l) / l)[l:-l])
        print(namestr(loss), '%.5g' % (np.mean(loss[-l:])))
    for acc in accs:
        ax2.plot(np.convolve(np.array(acc), np.ones(l) / l)[l:-l])
        print(namestr(acc), '%.5g' % (np.mean(acc[-l:])))
    ax1.legend([namestr(loss) for loss in losses], loc='upper left')
    ax2.legend([namestr(acc) for acc in accs], loc='upper right')
    plt.savefig('trainning_curve.png')
    plt.close()

def plot_acc_switch(plot_log):
    accs = []
    for step in range(0, 50):
        # todo: step=0 means the env never switched, combined with visited(loss_mask),
        #  the acc should be almost 100
        step_right = []
        step_trials = []
        for sample in range(len(plot_log['acc'])):
            step_mask = (plot_log['switch'][sample] == step)
            right = (plot_log['acc'][sample] * plot_log['loss_mask'][sample] * step_mask).sum().item()
            step_right.append(right)
            step_trials.append((plot_log['loss_mask'][sample] * step_mask).sum().item())
        accs.append(sum(step_right) / sum(step_trials)) if sum(step_trials) != 0 else accs.append(0)

    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.plot(accs)
    ax1.set_xlabel('Steps after switch')
    ax1.set_ylabel('accuracy')
    plt.savefig('acc_switch.png')
    plt.close()

# ----------------------------------------------------------------------------
# -- initialize datasets, model, criterion and optimizer
# ----------------------------------------------------------------------------

# todo: tune args and task_params

# task of path integration
# input cat(xt, at), output prediction xt+1
# x one-hot, xdim = size**2
# a
size = 6
x_dim = size**2 + 3*(size//2)**2 + 3*(size//2) + 1  # 3*size**2 + 3*size + 1  # size ** 2
a_dim = 6
in_dim = x_dim + a_dim
out_dim = x_dim
seq_len = 500  # 500   # todo:seq_len and n_rollout, batch_size have been lengthened
n_rollout = 50  # 100->50  # todo: 100 seems not suitable?
args.batch_size = 60  # 50


dataset = PolygonDataset(size, shape='HexagonSquare', params=None)
sam = STM(in_dim, out_dim)  # todo: tune other params

if torch.cuda.is_available():
    sam.cuda()

print("====num params=====")
print(sam.calculate_num_params())
print("========")

criterion = nn.CrossEntropyLoss()
optimizer = optim.RMSprop(sam.parameters(),
                          lr=args.lr,
                          alpha=args.alpha,
                          momentum=args.momentum)



# ----------------------------------------------------------------------------
# -- basic training loop
# ----------------------------------------------------------------------------
losses = []
train_acc = []
test_acc = []
plot_log = {'acc':[], 'switch':[], 'loss_mask':[]}   # log for plot figure acc-steps_after_switch

for iter in tqdm(range(args.num_iters)):
    # -----Generate and transfer new data(x, a, visited), reset sam's memory------
    sam.init_sequence(batch_size=args.batch_size)  # todo: reset memory?
    x, a, visited, switch = dataset.sample_from_new_mapping(seq_len, bs=args.batch_size, append_to_buffer=False)
    x_tensor = torch.stack([
        torch.stack([torch.eye(x_dim)[i] for i in j], dim=0)
        for j in x], dim=0)
    a_tensor = torch.stack([
        torch.stack([torch.eye(a_dim)[i] for i in j], dim=0)
        for j in a], dim=0)    # todo: static action or not
    loss_mask = torch.FloatTensor(visited)
    switch = torch.LongTensor(switch)
    labels = torch.LongTensor(x)
    if torch.cuda.is_available():
        loss_mask, labels \
            = loss_mask.cuda(), labels.cuda()
    # x_tensor[b, s, x_dim] a_tensor[b, s, a_dim]
    # loss_mask[b, s], labels[b, s], switch[b, s]
    # ---------------------------------------------------------

    # --------n_rollout batch forward throught sam each time-------------------
    # --------then detach and backward
    sam.train() if iter % 2 else sam.eval()
    for roll_step in range(seq_len // n_rollout):
        out = []
        for i in range(n_rollout):
            in_data = torch.cat((x_tensor.cuda(), a_tensor.cuda()), dim=2)[:, roll_step*n_rollout+i]
            sout, _ = sam(in_data)  # sout[b, x_dim]
            out.append(sout)
        out = torch.stack(out, dim=1)  # out[b, s, xdim]
        out = out[:, :-1] * loss_mask[:, roll_step*n_rollout:(roll_step+1)*n_rollout].unsqueeze(-1)[:, 1:]

        # --------train loop, calculate loss and backward, step
        if iter % 2:
            loss = criterion(out.view(-1, x_dim),
                    labels[:, roll_step*n_rollout+1:(roll_step+1)*n_rollout].contiguous().view(-1,))

            losses.append(loss.item())
            optimizer.zero_grad()
            loss.backward()

            if args.clip_grad>0:
                nn.utils.clip_grad_value_(sam.parameters(), args.clip_grad)

            optimizer.step()

        # -------detach memory-----------------
        previous = []
        for s in range(len(sam.previous_state)):
            previous.append(sam.previous_state[s].detach())
        sam.previous_state = previous

        # ----------calculate error------------
        acc = torch.argmax(out, dim=-1) == labels[:, roll_step*n_rollout+1:(roll_step+1)*n_rollout]
        if not (iter%2):
            plot_log['acc'].append(acc.detach().cpu())
            plot_log['switch'].append(switch[:, roll_step*n_rollout:(roll_step+1)*n_rollout][:, 1:].detach().cpu())
            plot_log['loss_mask'].append(loss_mask[:, roll_step*n_rollout:(roll_step+1)*n_rollout][:, 1:].detach().cpu())
        acc = acc * loss_mask[:, roll_step*n_rollout:(roll_step+1)*n_rollout][:, 1:]
        # todo: the calculation of acc should be weighted by trials
        acc = acc.sum() / loss_mask[:, roll_step*n_rollout:(roll_step+1)*n_rollout][:, 1:].sum()
        train_acc.append(acc.cpu().item()) if iter % 2 else test_acc.append(acc.cpu().item())

    # ---logging---
    if iter % 10 == 1:
        plot_and_print([losses], [train_acc, test_acc], smooth_length=1)
    if iter % 50 == 1:
        plot_acc_switch(plot_log)
        plot_log = {'acc': [], 'switch': [], 'loss_mask': []}
        torch.save(sam.state_dict(), 'sam.pth')
