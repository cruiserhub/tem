# Experiments of transformer on HexagonSquare environment(predict next x)

## Code:
commit ad9d2946f8ce0b5a7c43ec5010719cb4e0cab781 (HEAD -> master)  
Author: tlk <tlk16@mails.tsinghua.edu.cn>  
Date:   Sat Jan 23 21:16:11 2021 +0800  

## Parameters:
Didn't call random.seed()  
3:  python train_transformer_on_square.py -seq_len=500 -n_warmup_steps=4000 -d_model=256 -d_k=32 -d_v=32 -d_inner=1024 -n_layer=6 -figname=3 -devices='6'  
6:  python train_transformer_on_square.py -seq_len=500 -n_warmup_steps=4000 -d_model=128 -n_head=4 -d_k=32 -d_v=32 -d_inner=512 -n_layer=6 -figname=6 -devices='7'  
7:  python train_transformer_on_square.py -seq_len=500 -n_warmup_steps=4000 -d_model=128 -n_head=4 -d_k=32 -d_v=32 -d_inner=512 -n_layer=3 -figname=7 -devices='5'  

##  Acc: (mean along samples from last 500 epochs, std are estimated)
3: train: 95.3+-0.3  test: 95.9+-0.5  
6: train: 93.0+-0.5  test: 93.2+-0.5  
7: train: 85.7+-0.6  test: 87.8+-0.6  

## Png
*_switch.png: y:Acc - x:Steps after switch  
steps=0 means the env never switched  
attention that acc calculation only involves those x that were visited

## Analysis
1. Result 7 may be improved with longer training, 
since test acc is significantly higher than train acc

2. More weights are helpful to improve results, n_layer may be an important parameter
(3:9900032 > 6:2492416 > 7:1255936)

3. Acc of step=1 is ~60% in result 7, but more than 90% in result 3, 6.
Acc calculation only involves those x that were visited,
so transformer has visited that x even step=1, and it is able to remember 
all the path of Hexagon->Square->Hexagon to achieve 90% acc.

4. Switch.png shows that with enough weights, 
transformer can solve structure inference by remember everything

