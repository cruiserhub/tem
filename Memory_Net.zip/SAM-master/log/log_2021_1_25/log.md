# Experiments of transformer on HexagonSquare environment (estimate the environment)

## Code:
commit 2df5ba4682e3e0b6b891a2fbfddead42b392d82e (HEAD -> structure_classification)
Author: tlk <tlk16@mails.tsinghua.edu.cn>
Date:   Mon Jan 25 15:53:41 2021 +0800

## Parameters:
Didn't call random.seed()  
python train_transformer_on_square.py -seq_len=200 -n_warmup_steps=2048 -d_model=128 -n_head=4 -d_k=32 -d_v=32 -d_inner=512 -n_layer=6 -figname=classify -devices='7' 

##  Acc: (mean along samples from last 200 epochs, std are estimated)
train: 99.3+-0.1  test: 99.2+-0.1  
 
## Png
*_switch.png: y:Acc - x:Steps after switch  
steps=0 means the env never switched  

## Analysis
1. Structure inference(classifying the two environments) is easy for transformer.

