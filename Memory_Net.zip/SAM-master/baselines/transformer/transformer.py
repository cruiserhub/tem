"""
Transformer for structure inference task, Jan 22, 2021
Only use Encoder, subsequent_mask is applied to each Attention layer.
"""

import math
import torch
import torch.nn as nn

import psutil
import os


def memory_usage():
    mem_available = psutil.virtual_memory().available
    mem_process = psutil.Process(os.getpid()).memory_info().rss
    return round(mem_process / 1024 / 1024, 2), round(mem_available / 1024 / 1024, 2)


class Attention(nn.Module):
    def __init__(self, n_head, d_k, d_v, d_model):
        super().__init__()
        self.n_head = n_head
        self.d_k = d_k
        self.d_v = d_v

        self.wq = nn.Linear(d_model, n_head * d_k, bias=False)
        self.wk = nn.Linear(d_model, n_head * d_k, bias=False)
        self.wv = nn.Linear(d_model, n_head * d_v, bias=False)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, query, query_mask, key, key_mask, mask_subsequent=False):
        """
        Here the final dimension of query, key, value are 512, not 64.(before a linear trans)
        value is the same as key.
        :param query: [batch_size, seq_len1, d_model]
        :param key: [batch_size, seq_len2, d_model]
        :param query_mask: [256, seq_len1]
        :param key_mask: [256, seq_len2]
        :return: [batch_size, seq_len1, 8, 64]
        """

        query = query * query_mask.float().view(*query.shape[0:2], 1)
        key = key * key_mask.float().view(*key.shape[0:2], 1)
        subsequent_mask = self.get_subsequent_mask(mask_subsequent, query, key)

        q = self.wq(query).view(*query.shape[0:2], self.n_head, self.d_k).permute(0, 2, 1, 3)  # [b, 8, s1, 64]
        k = self.wk(key).view(*key.shape[0:2], self.n_head, self.d_k).permute(0, 2, 3, 1)  # [b, 8, 64, s2]
        v = self.wv(key).view(*key.shape[0:2], self.n_head, self.d_v).permute(0, 2, 1, 3)  # [b, 8, s2, 64]
        attn = self.softmax((torch.matmul(q, k) / math.sqrt(self.d_k)).masked_fill(subsequent_mask == 0, -1e15))
        return attn.matmul(v).permute(0, 2, 1, 3)  # [b, 8, s1, s2] * [b, 8, s2, 64] => [b, 8, s1, 64]
        # [s1 64] [64 s2] [s2 64]

    def get_subsequent_mask(self, mask_subsequent, query, key):
        '''
        For masking out the subsequent info.
        '''
        s1 = query.shape[1]
        s2 = key.shape[1]
        if mask_subsequent:
            subsequent_mask = (1 - torch.triu(
                torch.ones((1, s1, s2), device=query.device), diagonal=1))
        else:
            subsequent_mask = torch.ones((1, s1, s2), device=query.device)
        return subsequent_mask


class PointwiseFFN(nn.Module):
    def __init__(self, d_model, d_inner):
        super().__init__()
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_inner),
            nn.ReLU(),
            nn.Linear(d_inner, d_model)
        )

    def forward(self, x):
        """

        :param x: [batch_size, seq_len, 8, 64]
        :return: [batch_size, seq_len, 512]
        """
        x = x.view(x.shape[0], x.shape[1], x.shape[2] * x.shape[3])
        return self.ffn(x)


class Encoder_layer(nn.Module):
    def __init__(self, dropout, n_head, d_k, d_v, d_model, d_inner):
        super().__init__()
        self.d_v = d_v
        self.n_head = n_head
        self.d_model = d_model

        self.attention = Attention(n_head, d_k, d_v, d_model)
        self.attention_dp = nn.Dropout(dropout)
        self.attention_ln = nn.LayerNorm([n_head, d_v])  # todo: layernorm

        self.ffn = PointwiseFFN(d_model, d_inner)
        self.ffn_dp = nn.Dropout(dropout)  # todo: dim of dropout?
        self.ffn_ln = nn.LayerNorm(d_model)  # todo: layernorm

    def forward(self, x, mask):
        """

        :param x, src_emb: [batch_size, seq_len, d_model]
        :param mask, src_mask: [batch_size, seq_len]
        :return:
        """
        # todo: encoder layer's mask_subsequent has been set to True
        # if it's False, transformer should learn fast
        x = self.attention_ln(x.view(*x.shape[0:2], self.n_head, self.d_v) + self.attention_dp(
            self.attention(x, mask, x, mask, mask_subsequent=True)))  # [batch_size, seq_len, 8, 64]
        x = self.ffn_ln(x.view(*x.shape[0:2], self.d_model) + self.ffn_dp(self.ffn(x)))  # [batch_size, seq_len, 512]
        return x


class Decoder_layer(nn.Module):
    def __init__(self, dropout, n_head, d_k, d_v, d_model, d_inner):
        super().__init__()
        self.d_model = d_model
        self.d_v = d_v
        self.n_head = n_head

        self.self_attention = Attention(n_head, d_k, d_v, d_model)
        self.self_attention_dp = nn.Dropout(dropout)
        self.self_attention_ln = nn.LayerNorm([n_head, d_v])  # todo: layernorm

        self.enc_attention = Attention(n_head, d_k, d_v, d_model)
        self.enc_attention_dp = nn.Dropout(dropout)
        self.enc_attention_ln = nn.LayerNorm([n_head, d_v])  # todo: layernorm

        self.ffn = PointwiseFFN(d_model, d_inner)
        self.ffn_dp = nn.Dropout(dropout)
        self.ffn_ln = nn.LayerNorm(d_model)  # todo: layernorm, along which dim?

    def forward(self, x, mask, encoding, encoding_mask):
        """

        :param x, src_emb: [batch_size, seq_len, d_model]
        :param mask, src_mask: [batch_size, seq_len]
        :return:
        """

        x = self.self_attention_ln(x.view(*x.shape[0:2], self.n_head, self.d_v) + self.self_attention_dp(
            self.self_attention(x, mask, x, mask, mask_subsequent=True)))  # [batch_size, seq_len, 8, 64]
        # print(x.shape)
        x = self.enc_attention_ln(x + self.enc_attention_dp(
            self.enc_attention(x.view(*x.shape[0:2], self.d_model), mask, encoding,
                               encoding_mask)))  # [batch_size, seq_len, 8, 64]
        # print(x.shape)
        x = self.ffn_ln(x.view(*x.shape[0:2], self.d_model) + self.ffn_dp(self.ffn(x)))  # [batch_size, seq_len, 512]
        return x


class Encoder(nn.Module):
    def __init__(self, dropout, n_layers, n_head, d_k, d_v, d_model, d_inner):
        super().__init__()
        self.encoder = nn.ModuleList(
            [Encoder_layer(dropout, n_head, d_k, d_v, d_model, d_inner) for _ in range(n_layers)]
        )

    def forward(self, x, mask):
        """

        :param x: [batch_size, seq_len, d_model]
        :return:
        """
        for encoder_layer in self.encoder:
            x = encoder_layer(x, mask)
        return x


class Decoder(nn.Module):
    def __init__(self, dropout, n_layers, n_head, d_k, d_v, d_model, d_inner):
        super().__init__()
        self.decoder = nn.ModuleList(
            [Decoder_layer(dropout, n_head, d_k, d_v, d_model, d_inner) for _ in range(n_layers)]
        )

    def forward(self, x, mask, encoding, encoding_mask):
        """

        :param x: [batch_size, seq_len, d_model]
        :return:
        """
        for decoder_layer in self.decoder:
            x = decoder_layer(x, mask, encoding, encoding_mask)
        return x


class Transformer(nn.Module):
    ''' A sequence to sequence model with attention mechanism. '''

    def __init__(self, n_src_vocab, n_trg_vocab, src_pad_idx, trg_pad_idx, d_word_vec=512, d_model=512, d_inner=2048,
                 n_layers=6, n_head=8, d_k=64, d_v=64, dropout=0.1, n_position=200, trg_emb_prj_weight_sharing=True,
                 emb_src_trg_weight_sharing=True):
        # todo: unused parameters

        super().__init__()
        # assert n_src_vocab == n_trg_vocab   todo: assert is deprecated
        assert src_pad_idx == trg_pad_idx
        self.d_model = d_model
        self.pad_idx = src_pad_idx
        self.n_src_vocab = n_src_vocab
        self.n_trg_vocab = n_trg_vocab

        self.embedding = nn.Linear(n_src_vocab, d_model,
                                   bias=False)  # todo： nn.Embedding changed to nn.Linear(bias=False)
        self.dropout = nn.Dropout(dropout)
        self.encoder = Encoder(dropout, n_layers, n_head, d_k, d_v, d_model, d_inner)
        self.decoder = Decoder(dropout, n_layers, n_head, d_k, d_v, d_model, d_inner)
        self.output_layer = nn.Linear(self.d_model, n_trg_vocab, bias=False)

        # self.output_layer.weight = self.embedding.weight  todo: the weight sharing is deprecated
        # todo: check whether the sharing is successful
        self.x_logit_scale = d_model ** (-0.5)

    def forward(self, src_seq):
        """
        # todo: input only src_seq, use only encoder
        :param src_seq: [batch_size, src_seq_len, n_src_vocab]
        :return: [batch_size, trg_seq_len, n_trg_vocab]
        """
        # todo:needn't mask, because all seq have same length
        src_mask = torch.ones(src_seq.shape[0], src_seq.shape[1]).to(src_seq.device)  # src_seq != self.pad_idx

        src_emb = self.embedding(src_seq)  # [batch_size, seq_len, 512]

        src_emb = self.dropout(src_emb + self.cal_pos_codes(src_seq.shape[1],
                                                            src_seq.device))  # [batch_size, seq_len, 512] + [seq_len, 512]

        encodings = self.encoder(src_emb, src_mask)  # [batch_size, seq_len, 512]

        return self.output_layer(encodings) * self.x_logit_scale  # todo: scale or softmax? bias=False?

    def cal_pos_codes(self, seq_len, device):
        """

        :param seq_len:
        :return: [seq_len, d_model]
        """
        # todo: the frequency of pos codes should be adapted to seq_len?
        pos_enc = [[math.sin(pos / pow(10000, 2 * i / self.d_model)) if (i % 2 == 0)
                    else math.cos(pos / pow(10000, 2 * i / self.d_model))
                    for i in range(self.d_model)]
                   for pos in range(seq_len)]

        return torch.Tensor(pos_enc).to(device)

    def calculate_num_params(self):
        """Returns the total number of parameters."""
        num_params = 0
        for p in self.parameters():
            num_params += p.data.view(-1).size(0)
        return num_params


if __name__ == "__main__":
    batch_size = 256
    src_seq_len = 32
    trg_seq_len = 30
    n_src_vocab = 1000
    n_trg_vocab = 1000
    t = Transformer(n_src_vocab=n_src_vocab, n_trg_vocab=n_trg_vocab, src_pad_idx=1, trg_pad_idx=1)
    src = torch.randn(batch_size, src_seq_len, n_src_vocab)
    output = t(src)
    print(memory_usage())
