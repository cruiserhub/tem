"""
train transformer model on square env, Jan 22, 2021
"""

import numpy as np
import os
import random

import torch
from torch import nn, optim
import matplotlib.pyplot as plt

from square_map import PolygonDataset
from baselines.transformer.transformer import Transformer
from baselines.transformer.optim import ScheduledOptim

import argparse

def plot_and_print(losses, accs, smooth_length, figname):
    def namestr(obj):
        return [name for name in globals() if globals()[name] is obj][0]
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax2 = ax1.twinx()
    l = smooth_length # len(train_loader)
    for loss in losses:
        ax1.plot(np.convolve(np.array(loss), np.ones(l) / l)[l:-l])
        print(namestr(loss), '%.5g' % (np.mean(loss[-l:])))
    for acc in accs:
        ax2.plot(np.convolve(np.array(acc), np.ones(l) / l)[l:-l])
        print(namestr(acc), '%.5g' % (np.mean(acc[-l:])))
    ax1.legend([namestr(loss) for loss in losses], loc='upper left')
    ax2.legend([namestr(acc) for acc in accs], loc='upper right')
    plt.savefig(figname + '_curve.png')
    plt.close()
    print('-----------------------------')

def plot_acc_switch(plot_log, figname):
    accs = []
    for step in range(0, 50):
        # todo: step=0 means the env never switched, combined with visited(loss_mask),
        #  the acc should be almost 100
        step_right = []
        step_trials = []
        for sample in range(len(plot_log['acc'])):
            step_mask = (plot_log['switch'][sample] == step)
            right = (plot_log['acc'][sample] * plot_log['loss_mask'][sample] * step_mask).sum().item()
            step_right.append(right)
            step_trials.append((plot_log['loss_mask'][sample] * step_mask).sum().item())
        accs.append(sum(step_right) / sum(step_trials)) if sum(step_trials) != 0 else accs.append(0)

    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.plot(accs)
    plt.savefig(figname+ '_switch.png')
    plt.close()

# ----------------------------------------------------------------------------
# -- initialize datasets, model, criterion and optimizer
# ----------------------------------------------------------------------------

# task of path integration
# input cat(xt, at), output prediction xt+1
# x one-hot, xdim = size**2
# a
parser = argparse.ArgumentParser()
parser.add_argument('-size', type=int, default=6)
parser.add_argument('-num_iters', type=int, default=50000)
parser.add_argument('-seq_len', type=int, default=500)
parser.add_argument('-batch_size', type=int, default=60)
parser.add_argument('-n_warmup_steps', type=int, default=4000)
parser.add_argument('-d_inner', type=int, default=2048)
parser.add_argument('-n_layer', type=int, default=6)
parser.add_argument('-d_model', type=int, default=512)
parser.add_argument('-n_head', type=int, default=8)
parser.add_argument('-d_k', type=int, default=64)
parser.add_argument('-d_v', type=int, default=64)
parser.add_argument('-figname', default='hhh')
parser.add_argument('-devices', default='6,7')
args = parser.parse_args()

x_dim = args.size**2 + 3*(args.size//2)**2 + 3*(args.size//2) + 1  # 3*size**2 + 3*size + 1  # size ** 2
a_dim = 6
in_dim = x_dim + a_dim
out_dim = x_dim
# todo: tune seq_len, warm_up, d_model/n_head, d_inner, n_layer


dataset = PolygonDataset(args.size, shape='HexagonSquare', params=None)
transformer = Transformer(in_dim, out_dim, src_pad_idx=None, trg_pad_idx=None,
                          d_word_vec=None, d_model=args.d_model, d_inner=args.d_inner,
                          n_layers=args.n_layer, n_head=args.n_head, d_k=args.d_k, d_v=args.d_v,
                          dropout=0.1
                          )
os.environ['CUDA_VISIBLE_DEVICES'] = args.devices
transformer = nn.DataParallel(transformer)
transformer = transformer.cuda()

print("====num params=====")
print(transformer.module.calculate_num_params())
print("========")

criterion = nn.CrossEntropyLoss()
optimizer = ScheduledOptim(
        optim.Adam(transformer.parameters(), betas=(0.9, 0.98), eps=1e-09),
        2.0, args.d_model, args.n_warmup_steps)


# ----------------------------------------------------------------------------
# -- basic training loop
# ----------------------------------------------------------------------------
losses = []
train_acc = []
test_acc = []
plot_log = {'acc':[], 'switch':[], 'loss_mask':[]}   # log for plot figure acc-steps_after_switch

for iter in range(args.num_iters):
    # -------Generate and transfer new data(x, a, visited)----------------
    if iter % 10:
        if (len(dataset.buffer['xs']) < 50 * args.batch_size) or (random.random() < 0.1):
            x, a, visited, switch = dataset.sample_from_new_mapping(args.seq_len, bs=args.batch_size, append_to_buffer=True)
            if len(dataset.buffer['xs']) > 500 * args.batch_size:
                dataset.del_buffer_from_head(del_len=args.batch_size)
        else:
            x, a, visited, switch = dataset.sample_from_buffer(bs=args.batch_size)
    else:
        x, a, visited, switch = dataset.sample_from_new_mapping(args.seq_len, bs=args.batch_size, append_to_buffer=False)

    x_tensor = torch.stack([
        torch.stack([torch.eye(x_dim)[i] for i in j], dim=0)
        for j in x], dim=0)
    a_tensor = torch.stack([
        torch.stack([torch.eye(a_dim)[i] for i in j], dim=0)
        for j in a], dim=0)
    loss_mask = torch.FloatTensor(visited).cuda()
    switch = torch.LongTensor(switch).cuda()
    labels = torch.LongTensor(x).cuda()
    # x_tensor[b, s, x_dim] a_tensor[b, s, a_dim]
    # loss_mask[b, s], labels[b, s], switch[b, s]
    # ---------------------------------------------------------

    # -------------Forward through transformer-------------------
    # -------------then backward
    transformer.train() if iter % 10 else transformer.eval()
    in_data = torch.cat((x_tensor.cuda(), a_tensor.cuda()), dim=2)
    out = transformer(in_data) # out[b, s, xdim]
    out = out[:, :-1] * loss_mask.unsqueeze(-1)[:, 1:]

    # --------train loop, calculate loss and backward, step
    if iter % 10:    # todo: iter%2 changed to iter%10
        loss = criterion(out.view(-1, x_dim),
                labels[:, 1:].contiguous().view(-1,))

        losses.append(loss.item())
        optimizer.zero_grad()
        loss.backward()

        optimizer.step_and_update_lr()

    # ----------calculate error------------
    acc = torch.argmax(out, dim=-1) == labels[:, 1:]
    if not (iter % 10):  # todo: here was iter % 2
        plot_log['acc'].append(acc.detach().cpu())
        plot_log['switch'].append(switch[:, 1:].detach().cpu())
        plot_log['loss_mask'].append(loss_mask[:, 1:].detach().cpu())
    acc = acc * loss_mask[:, 1:]
    # todo: the calculation of acc should be weighted by trials
    acc = acc.sum() / loss_mask[:, 1:].sum()
    train_acc.append(acc.cpu().item()) if iter % 10 else test_acc.extend([acc.cpu().item() for _ in range(9)])
    # ---logging---
    if iter % 100 == 99:
        print(iter, optimizer._optimizer.param_groups[0]['lr'])
        plot_and_print([losses], [train_acc, test_acc], smooth_length=1, figname=args.figname)
    if iter % 200 == 1:
        plot_acc_switch(plot_log, figname=args.figname)
        plot_log = {'acc': [], 'switch': [], 'loss_mask': []}

